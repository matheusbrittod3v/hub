<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia><?php echo e(config('app.name', 'HubPorn')); ?></title>

        <!-- SEO Meta Tags -->
        <meta name="description" content="<?php echo e($page['props']['seo']['description'] ?? 'Os melhores vídeos e fotos em um só lugar.'); ?>">
        <meta name="keywords" content="<?php echo e($page['props']['seo']['keywords'] ?? 'porn, videos, photos, adult content'); ?>">
        <meta name="robots" content="index, follow">
        <link rel="canonical" href="<?php echo e(url()->current()); ?>">
        
        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="website">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:title" content="<?php echo e($page['props']['seo']['title'] ?? config('app.name', 'HubPorn')); ?>">
        <meta property="og:description" content="<?php echo e($page['props']['seo']['description'] ?? 'Os melhores vídeos e fotos em um só lugar.'); ?>">
        <meta property="og:image" content="<?php echo e($page['props']['seo']['image'] ?? url('/assets/images/og-image.jpg')); ?>">

        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:title" content="<?php echo e($page['props']['seo']['title'] ?? config('app.name', 'HubPorn')); ?>">
        <meta property="twitter:description" content="<?php echo e($page['props']['seo']['description'] ?? 'Os melhores vídeos e fotos em um só lugar.'); ?>">
        <meta property="twitter:image" content="<?php echo e($page['props']['seo']['image'] ?? url('/assets/images/og-image.jpg')); ?>">

        <!-- Performance: Preconnect to external resources -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link rel="preconnect" href="<?php echo e(env('R2_URL', 'https://cdn.hubporn.online')); ?>" crossorigin>
        <link rel="dns-prefetch" href="<?php echo e(env('R2_URL', 'https://cdn.hubporn.online')); ?>">
        <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
        
        <!-- Fonts with display=swap for better LCP -->
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

        <!-- Icons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" media="print" onload="this.media='all'">
        <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>
        
        <!-- SweetAlert2 -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <!-- Scripts -->
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\Users\britto\Desktop\alfasever\hubporn\hubporn-site\hubporn.online\resources\views/app.blade.php ENDPATH**/ ?>